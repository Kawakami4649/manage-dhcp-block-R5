sudo apt update
sudo apt install -y ebtables
sudo ./setup-ebtables.sh
