#!/bin/bash

set -e

RC_LOCAL="/etc/rc.local"
BACKUP="/etc/rc.local.bak.$(date +%Y%m%d-%H%M%S)"

MARK_START="# >>> DHCP-GUARD START >>>"

if [[ $EUID -ne 0 ]]; then
    echo "sudo で実行してください"
    exit 1
fi

echo "rc.local をバックアップします: $BACKUP"
cp "$RC_LOCAL" "$BACKUP"

# 既に挿入済みなら終了
if grep -q "$MARK_START" "$RC_LOCAL"; then
    echo "既に DHCP-GUARD は存在します"
    exit 0
fi

TMP=$(mktemp)

EXIT_FOUND=false

while IFS= read -r line; do

    if [[ "$line" == "exit 0" ]]; then

        EXIT_FOUND=true

        cat << 'EOF' >> "$TMP"

# >>> DHCP-GUARD START >>>

NETPLAN_FILE="/etc/netplan/50-cloud-init.yaml"

#IFACE="br0"
IFACE="eth0"
#RULE="! -i ${IFACE} -p IPv4 --ip-proto udp --ip-dport 67:68 -j DROP"
RULE="-i ${IFACE} -p IPv4 --ip-proto udp --ip-dport 67:68 -j DROP"

log() {
    logger -t dhcp-guard "$1"
}

is_dhcp_enabled() {

    VALUE=$(awk '
        $0 ~ /^[[:space:]]*eth0:/ { in_eth=1; next }
        in_eth && $0 ~ /^[[:space:]]*[a-zA-Z0-9_-]+:/ { exit }
        in_eth && $0 ~ /dhcp4:/ {
            gsub(/ /,"")
            split($0,a,":")
            print a[2]
            exit
        }
    ' "$NETPLAN_FILE")

    [ "$VALUE" = "true" ]
}

if is_dhcp_enabled; then

    ebtables -D FORWARD $RULE 2>/dev/null
    log "DHCP ALLOW on ${IFACE}"

else

    if ! ebtables -C FORWARD $RULE 2>/dev/null; then
        ebtables -A FORWARD $RULE
        log "DHCP BLOCK on ${IFACE}"
    fi

fi

# <<< DHCP-GUARD END <<<

EOF

    fi

    echo "$line" >> "$TMP"

done < "$RC_LOCAL"

# exit 0 が無かった場合
if [ "$EXIT_FOUND" = false ]; then

    cat << 'EOF' >> "$TMP"

# >>> DHCP-GUARD START >>>

NETPLAN_FILE="/etc/netplan/50-cloud-init.yaml"
IFACE="eth0"

RULE="! -i ${IFACE} -p IPv4 --ip-proto udp --ip-dport 67:68 -j DROP"

if grep -q "dhcp4: true" "$NETPLAN_FILE" 2>/dev/null; then
    ebtables -D FORWARD $RULE 2>/dev/null
else
    ebtables -A FORWARD $RULE 2>/dev/null
fi

# <<< DHCP-GUARD END <<<

exit 0

EOF

fi

mv "$TMP" "$RC_LOCAL"
chmod +x "$RC_LOCAL"

echo
echo "正常に挿入されました"
