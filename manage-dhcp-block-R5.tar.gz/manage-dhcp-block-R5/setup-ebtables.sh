#!/bin/bash

set -e

# TinyBox Network Interface
if [ -f /etc/tinybox/network.conf ]; then
    source /etc/tinybox/network.conf
fi
ETH_IF="${ETH_IF:-eth0}"
WLAN_IF="${WLAN_IF:-wlan0}"

RC_LOCAL="/etc/rc.local"
BACKUP="/etc/rc.local.bak.$(date +%Y%m%d-%H%M%S)"

MARK_START="# >>> DHCP-GUARD START >>>"

if [[ $EUID -ne 0 ]]; then
    echo "sudo で実行してください"
    exit 1
fi

if [ ! -f "$RC_LOCAL" ]; then
    echo "$RC_LOCAL が存在しません"
    exit 1
fi

# 既に挿入済みなら終了(バックアップを作る前に判定)
if grep -qF "$MARK_START" "$RC_LOCAL"; then
    echo "既に DHCP-GUARD は存在します"
    exit 0
fi

echo "rc.local をバックアップします: $BACKUP"
cp "$RC_LOCAL" "$BACKUP"

# rc.local に挿入するブロック本体
# (クォート付き heredoc のため、変数は rc.local 実行時に展開される)
BLOCK=$(mktemp)
TMP=$(mktemp)
trap 'rm -f "$BLOCK" "$TMP"' EXIT

cat << 'EOF' > "$BLOCK"

# >>> DHCP-GUARD START >>>

# 起動時にも設定ファイルを読み込む(setup 実行時の変数は引き継がれない)
if [ -f /etc/tinybox/network.conf ]; then
    . /etc/tinybox/network.conf
fi
ETH_IF="${ETH_IF:-eth0}"

NETPLAN_FILE="/etc/netplan/50-cloud-init.yaml"

IFACE="$ETH_IF"
RULE="-i ${IFACE} -p IPv4 --ip-proto udp --ip-dport 67:68 -j DROP"

dhcp_guard_log() {
    logger -t dhcp-guard "$1"
}

is_dhcp_enabled() {

    VALUE=$(awk -v iface="$ETH_IF" '
        { match($0, /^[[:space:]]*/); indent = RLENGTH }
        !in_if && $0 ~ ("^[[:space:]]*" iface ":[[:space:]]*$") {
            in_if = 1; base = indent; next
        }
        # 空行・コメント以外で、インデントが同じか浅くなったらブロック終了
        in_if && $0 !~ /^[[:space:]]*(#.*)?$/ && indent <= base { exit }
        in_if && $0 ~ /dhcp4:/ {
            sub(/#.*/, "")
            gsub(/[[:space:]]/, "")
            split($0, a, ":")
            print a[2]
            exit
        }
    ' "$NETPLAN_FILE" 2>/dev/null)

    [ "$VALUE" = "true" ]
}

# rc.local が -e 付きで実行されても中断しないよう || true を付与
if is_dhcp_enabled; then

    ebtables -D FORWARD $RULE 2>/dev/null || true
    dhcp_guard_log "DHCP ALLOW on ${IFACE}"

else

    if ! ebtables -C FORWARD $RULE 2>/dev/null; then
        ebtables -A FORWARD $RULE || true
        dhcp_guard_log "DHCP BLOCK on ${IFACE}"
    fi

fi

# <<< DHCP-GUARD END <<<

EOF

INSERTED=false

while IFS= read -r line || [ -n "$line" ]; do

    # 最初の "exit 0" の直前にブロックを挿入
    if [ "$INSERTED" = false ] && [[ "$line" =~ ^[[:space:]]*exit[[:space:]]+0[[:space:]]*$ ]]; then
        cat "$BLOCK" >> "$TMP"
        INSERTED=true
    fi

    printf '%s\n' "$line" >> "$TMP"

done < "$RC_LOCAL"

# exit 0 が無かった場合は末尾に追加
if [ "$INSERTED" = false ]; then
    cat "$BLOCK" >> "$TMP"
    echo "exit 0" >> "$TMP"
fi

cat "$TMP" > "$RC_LOCAL"
chmod +x "$RC_LOCAL"

echo
echo "正常に挿入されました (対象インターフェース: ${ETH_IF})"
